<?php
// Heading
$_['heading_title']    = 'Google Sitemap';

// Text
$_['text_extension']   = 'Расширения';
$_['text_success']     = 'Настройки модуля обновлены!';
$_['text_edit']        = 'Редактирование';

// Entry
$_['entry_status']     = 'Статус';
$_['entry_data_feed']  = 'Адрес';

// Error
$_['error_permission'] = 'У Вас нет прав для управления этим модулем!';

